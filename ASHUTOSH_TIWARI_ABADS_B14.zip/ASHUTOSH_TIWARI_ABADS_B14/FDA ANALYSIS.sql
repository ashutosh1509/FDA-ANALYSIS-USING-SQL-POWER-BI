USE FDA_ANALYSIS;

-- TASK 1 Identifying Approval Trends
-- Determine the number of drugs approved each year and provide insights into the yearly trends.
SELECT 
    EXTRACT(YEAR FROM DATE(ActionDate)) AS Year,
    COUNT(*) AS ApprovalCount
FROM RegActionDate
WHERE ActionType = 'AP'
GROUP BY EXTRACT(YEAR FROM DATE(ActionDate))
ORDER BY Year;

-- Identify the top three years that got the highest and lowest approvals, in descending and ascending order, respectively.
-- Top 3 years with highest approvals
SELECT
    EXTRACT(YEAR FROM DATE(ActionDate)) AS Year,
    COUNT(*) AS ApprovalCount
FROM RegActionDate
WHERE ActionType = 'AP'
GROUP BY EXTRACT(YEAR FROM DATE(ActionDate))
ORDER BY ApprovalCount DESC
LIMIT 3;

-- Top 3 years with lowest approvals
SELECT
    EXTRACT(YEAR FROM DATE(ActionDate)) AS Year,
    COUNT(*) AS ApprovalCount
FROM RegActionDate
WHERE ActionType = 'AP'
GROUP BY EXTRACT(YEAR FROM DATE(ActionDate))
ORDER BY ApprovalCount ASC
LIMIT 3;

--  Explore approval trends over the years based on sponsors. 
SELECT
    EXTRACT(YEAR FROM DATE(r.ActionDate)) AS Year,
    a.SponsorApplicant,
    COUNT(*) AS ApprovalCount
FROM RegActionDate r
JOIN Application a ON r.ApplNo = a.ApplNo
WHERE r.ActionType = 'AP'
GROUP BY EXTRACT(YEAR FROM DATE(r.ActionDate)), a.SponsorApplicant
ORDER BY Year, ApprovalCount DESC;

-- Rank sponsors based on the total number of approvals they received each year between 1939 and 1960.

WITH ApprovalCounts AS (
    SELECT
        EXTRACT(YEAR FROM DATE(r.ActionDate)) AS Year,
        a.SponsorApplicant,
        COUNT(*) AS ApprovalCount
    FROM RegActionDate r
    JOIN Application a ON r.ApplNo = a.ApplNo
    WHERE r.ActionType = 'AP'
    AND EXTRACT(YEAR FROM DATE(r.ActionDate)) BETWEEN 1939 AND 1960
    GROUP BY EXTRACT(YEAR FROM DATE(r.ActionDate)), a.SponsorApplicant
)
SELECT
    Year,
    SponsorApplicant,
    ApprovalCount,
    RANK() OVER (PARTITION BY Year ORDER BY ApprovalCount DESC) AS `Rank`
FROM ApprovalCounts
ORDER BY Year, `Rank`;

-- TASK 2 Segmentation Analysis Based on Drug MarketingStatus
-- 1. Group products based on MarketingStatus. Provide meaningful insights into the segmentation patterns.
SELECT
    CASE
        WHEN ProductMktStatus = 1 THEN 'Marketed'
        WHEN ProductMktStatus = 2 THEN 'Withdrawn'
        WHEN ProductMktStatus = 3 THEN 'Pending'
        WHEN ProductMktStatus = 4 THEN 'Pre-Market'
        ELSE 'Unknown'
    END AS MarketingStatus,
    COUNT(*) AS ProductCount,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS Percentage
FROM Product
GROUP BY ProductMktStatus
ORDER BY ProductCount DESC;

-- 2. Calculate the total number of applications for each MarketingStatus year-wise after the year 2010.
SELECT
    EXTRACT(YEAR FROM DATE(r.ActionDate)) AS Year,
    CASE
        WHEN p.ProductMktStatus = 1 THEN 'Marketed'
        WHEN p.ProductMktStatus = 2 THEN 'Withdrawn'
        WHEN p.ProductMktStatus = 3 THEN 'Pending'
        WHEN p.ProductMktStatus = 4 THEN 'Pre-Market'
        ELSE 'Unknown'
    END AS MarketingStatus,
    COUNT(DISTINCT r.ApplNo) AS ApplicationCount
FROM RegActionDate r
JOIN Product p ON r.ApplNo = p.ApplNo
WHERE EXTRACT(YEAR FROM DATE(r.ActionDate)) > 2010
GROUP BY EXTRACT(YEAR FROM DATE(r.ActionDate)), p.ProductMktStatus
ORDER BY Year, ApplicationCount DESC; 

-- 3. Identify the top MarketingStatus with the maximum number of applications and analyze its trend over time.
WITH ApplicationCounts AS (
    SELECT
        EXTRACT(YEAR FROM DATE(r.ActionDate)) AS Year,
        CASE
            WHEN p.ProductMktStatus = 1 THEN 'Marketed'
            WHEN p.ProductMktStatus = 2 THEN 'Withdrawn'
            WHEN p.ProductMktStatus = 3 THEN 'Pending'
            WHEN p.ProductMktStatus = 4 THEN 'Pre-Market'
            ELSE 'Unknown'
        END AS MarketingStatus,
        COUNT(DISTINCT r.ApplNo) AS ApplicationCount
    FROM RegActionDate r
    JOIN Product p ON r.ApplNo = p.ApplNo
    GROUP BY EXTRACT(YEAR FROM DATE(r.ActionDate)), p.ProductMktStatus
),
RankedApplicationCounts AS (
    SELECT
        Year,
        MarketingStatus,
        ApplicationCount,
        ROW_NUMBER() OVER (PARTITION BY Year ORDER BY ApplicationCount DESC) AS `Rank`
    FROM ApplicationCounts
)
SELECT
    Year,
    MarketingStatus,
    ApplicationCount,
    `Rank`
FROM RankedApplicationCounts
WHERE `Rank` = 1
ORDER BY Year;


-- TASK 3: Analyzing Products
-- 1. Categorize Products by dosage form and analyze their distribution.
SELECT
    Form,
    COUNT(*) AS ProductCount,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS Percentage
FROM Product
GROUP BY Form
ORDER BY ProductCount DESC;

-- 2. Calculate the total number of approvals for each dosage form and identify the most successful forms.
SELECT
    p.Form,
    COUNT(DISTINCT r.ApplNo) AS ApprovalCount
FROM Product p
JOIN RegActionDate r ON p.ApplNo = r.ApplNo
WHERE r.ActionType = 'AP'
GROUP BY p.Form
ORDER BY ApprovalCount DESC
LIMIT 10;

-- 3. Investigate yearly trends related to successful forms.
WITH SuccessfulForms AS (
    SELECT Form
    FROM Product p
    JOIN RegActionDate r ON p.ApplNo = r.ApplNo
    WHERE r.ActionType = 'AP'
    GROUP BY Form
    ORDER BY COUNT(DISTINCT r.ApplNo) DESC
    LIMIT 5
),
YearlyTrends AS (
    SELECT
        EXTRACT(YEAR FROM DATE(r.ActionDate)) AS Year,
        p.Form,
        COUNT(DISTINCT r.ApplNo) AS ApprovalCount
    FROM Product p
    JOIN RegActionDate r ON p.ApplNo = r.ApplNo
    WHERE r.ActionType = 'AP' AND p.Form IN (SELECT Form FROM SuccessfulForms)
    GROUP BY EXTRACT(YEAR FROM DATE(r.ActionDate)), p.Form
)
SELECT
    Year,
    Form,
    ApprovalCount
FROM YearlyTrends
ORDER BY Year, ApprovalCount DESC;

-- TASK 4: Exploring Therapeutic Classes and Approval Trends
-- 1. Analyze drug approvals based on the therapeutic evaluation code (TE_Code).

SELECT
    p.TECode,
    COUNT(DISTINCT r.ApplNo) AS ApprovalCount
FROM Product p
JOIN RegActionDate r ON p.ApplNo = r.ApplNo
WHERE r.ActionType = 'AP'
GROUP BY p.TECode
ORDER BY ApprovalCount DESC;

-- 2. Determine the therapeutic evaluation code (TE_Code) with the highest number of Approvals in each year.

WITH YearlyApprovals AS (
    SELECT
        EXTRACT(YEAR FROM DATE(r.ActionDate)) AS Year,
        p.TECode,
        COUNT(DISTINCT r.ApplNo) AS ApprovalCount,
        ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM DATE(r.ActionDate)) ORDER BY COUNT(DISTINCT r.ApplNo) DESC) AS `Rank`
    FROM Product p
    JOIN RegActionDate r ON p.ApplNo = r.ApplNo
    WHERE r.ActionType = 'AP'
    GROUP BY EXTRACT(YEAR FROM DATE(r.ActionDate)), p.TECode
),
TopApprovals AS (
    SELECT
        Year,
        TECode,
        ApprovalCount
    FROM YearlyApprovals
    WHERE `Rank` = 1
)
SELECT
    Year,
    TECode,
    ApprovalCount
FROM TopApprovals
ORDER BY Year;
